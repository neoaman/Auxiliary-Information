library(mvtnorm)
library(mixtools)  #for ellipse
library(MASS)
Rbvn <- function(muX =15,muY =30,rho,sX=3,sY=5,N) {
  mu <- c(muX,muY)
  sigma <- matrix(c(sX^2,sX*sY*rho,sX*sY*rho,sY^2),nrow = 2,ncol = 2)
  bvn <- mvrnorm(N, mu = mu, Sigma = sigma )
  colnames(bvn) <- c("X","Y")
  bvn
}

k <- Rbvn(rho = 0.75,N = 100)

rho3 <- c(0.75,0.85,0.95) # 3 Rho values 
N5 <- c(40,50,60,75,100) # 5 Population Sizes
seeds <- c(151,223,224,322,296,9,76,121,123,472,78,81,83,106,489,488)
Pop_list <- list(NULL)
k <- 10
count <- 1

for(i in rho3){
  for (j in N5) {
    
      set.seed(k)
      Rbvn(rho = i,N = j) -> Pop_list[[count]]
    k <- k+1
    count <- count+1
    
  }
}

Pop_list # The Population list of all 25 Populations 

#
D <- matrix(0,nrow = 15,ncol = 4) 
colnames(D) <- c("N","Mean_X","Mean_Y","Rho")


for (i in 1:15) {
  nrow(Pop_list[[i]]) -> D[i,1]
  mean(Pop_list[[i]][,1]) -> D[i,2]
  mean(Pop_list[[i]][,2]) -> D[i,3]
  cor(Pop_list[[i]][,1],Pop_list[[i]][,2]) -> D[i,4]
  
}
D # list to check 

#
# Sampling

#___________________________________________________________________
set.seed(1)
sample(1:nrow(Pop_list[[1]]),size = 5) -> n # !!!!!!!!! # For testing purpose
Pop_list[[1]][n,] -> sample_list[[cnt]]
cnt <- cnt+1
#__________________________________________________________________

sample_list <- list(NULL)
cnt <- 1

nrow(Pop_list[[1]])
for(s in c(5,10,15)){
  for (i in 1:15) {
    set.seed(i)
    sample(1:nrow(Pop_list[[i]]),size = s) -> n
    Pop_list[[i]][n,] -> sample_list[[cnt]]
    cnt <- cnt+1
  }
}
sample_list

#

d <- matrix(0,nrow = 45,ncol = 4) 
colnames(d) <- c("n","mean_x","mean_y","rho")
nrow(sample_list[[2]])
mean(sample_list[[1]][,1])
for (i in 1:45) {
  nrow(sample_list[[i]]) -> d[i,1]
  mean(sample_list[[i]][,1]) -> d[i,2]
  mean(sample_list[[i]][,2]) -> d[i,3]
  cor(sample_list[[i]][,1],sample_list[[i]][,2]) -> d[i,4]
  
}
d # table to check Here is the : sample size, sample mean of auxiliar variable, sample mean of y , and correlation rho 

#MEGA TABLE
Dd <- as.data.frame(cbind(rbind(D,D,D),d)) #information of all sample and their corresponding populat
round(Dd$mean_y) != round(Dd$Mean_Y)

plot(x = Dd$Mean_Y,type = "l")
lines(x = Dd$mean_y,type = "o")
diff <- abs(Dd$Mean_Y-Dd$mean_y)
plot(diff,type = "o")
Dd[which.min(diff),]

cols <- with(Dd, ifelse(round(Dd$mean_y) != round(Dd$Mean_Y),'pink','white' ))

library('htmlTable')
htmlTable(as.matrix(Dd), col.rgroup = cols)

#
#                              
#                               simple mean estimator _____ ybar
#                              
attach(Dd)

Test1_1 <- abs(Mean_Y - mean_y) #To see the difference between the populaion mean and the sample mean 
best_1 <- Dd[which.min(Test1),] # To see the least difference from population mean to sample mean

#lets add variance to the Dd and make it Dd_1______________________________________________
Dd_1 <- Dd
Dd_1$Var_X <- 0                                                                           #
count <- 1                                                                                #
for (i in 1:3) {
  for(j in 1:15){
   var(Pop_list[[j]][,1]) -> Dd_1[count,"Var_X"]
    count <- count+1
  }
}
Dd_1
#_____________________________________
Dd_1$Var_Y <- 0
count <- 1
for (i in 1:3) {
  for(j in 1:15){
    var(Pop_list[[j]][,2]) -> Dd_1[count,"Var_Y"]
    count <- count+1
  }
}
Dd_1
#__________________________________
Dd_1$var_x <- c(0)
count <- 1
for (i in 1:45) {
  var(sample_list[[i]][,1]) -> Dd_1[count,"var_x"]
  count <- count+1
}
Dd_1
#_____________________________________
Dd_1$var_y <- c(0)
count <- 1
for (i in 1:45) {
  var(sample_list[[i]][,2]) -> Dd_1[count,"var_y"]
  count <- count+1
}
Dd_1
#_____________________________________________________________________________________________

attach(Dd_1)
Test1_2 <-abs(Var_Y - var_y) 
Dd_1[which.min(Test1_2),]

