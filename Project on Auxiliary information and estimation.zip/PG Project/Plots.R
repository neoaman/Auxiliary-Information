#____________________________________________________________________________
# Estimator plot for Xi = Yi 
#____________________________________________________________________________
Xi <- 1:10
Yi <- Xi

xi_s <- t(combn(Xi,5)) # Samples from Xi Population values  Auxiliary information
yi_s <- t(combn(Yi,5)) # Samples from Yi Population values 

xi.m <- rowMeans(xi_s) # mean of all xi_s samples  Auxiliary

yi.m <- rowMeans(yi_s) # ----------------------------------mean of all yi_s samples ( For sample mean estimator) 
yi.p <- (yi.m*xi.m)/mean(Xi) # --------------------------  ( For product estimator) 
yi.r <- (yi.m*mean(Xi))/xi.m # --------------------------  ( For ratio estimator) 
yi.e <- yi.m*exp((mean(Xi)-xi.m)/(mean(Xi)+xi.m)) # -----  ( For exponential estimator) 
yi.sq <- yi.m*(mean(Xi)/xi.m)^.5  # ---------------------  ( For squre-root estimator) 

# plotting those values
plot(xi.m,yi.m)
lines(xi.m,yi.p,col="blue")
points(xi.m,yi.r,col="forestgreen")
points(xi.m,yi.e,col="red")
lines(xi.m,yi.sq,col="green")

#____________________________________________________________________________ 
# Estimator plot for Yi = Xi*0.75 
#____________________________________________________________________________
Xi <- 1:10
Yi <- Xi*0.75

xi_s <- t(combn(Xi,5)) # Samples from Xi Population values  Auxiliary information
yi_s <- t(combn(Yi,5)) # Samples from Yi Population values 

xi.m <- rowMeans(xi_s) # mean of all xi_s samples  Auxiliary

yi.m <- rowMeans(yi_s) # ----------------------------------mean of all yi_s samples ( For sample mean estimator) 
yi.p <- (yi.m*xi.m)/mean(Xi) # --------------------------  ( For product estimator) 
yi.r <- (yi.m*mean(Xi))/xi.m # --------------------------  ( For ratio estimator) 
yi.e <- yi.m*exp((mean(Xi)-xi.m)/(mean(Xi)+xi.m)) # -----  ( For exponential estimator) 
yi.sq <- yi.m*(mean(Xi)/xi.m)^.5  # ---------------------  ( For squre-root estimator) 

# plotting those values
plot(xi.m,yi.m)
lines(xi.m,yi.p,col="blue")
points(xi.m,yi.r,col="forestgreen")
points(xi.m,yi.e,col="red")
lines(xi.m,yi.sq,col="green")

#____________________________________________________________________________ 
# Estimator plot for Yi = 10+Xi*0.75 
#____________________________________________________________________________
Xi <- 1:10
Yi <- 2 + Xi*0.75

xi_s <- t(combn(Xi,5)) # Samples from Xi Population values  Auxiliary information
yi_s <- t(combn(Yi,5)) # Samples from Yi Population values 

xi.m <- rowMeans(xi_s) # mean of all xi_s samples  Auxiliary

yi.m <- rowMeans(yi_s) # ----------------------------------mean of all yi_s samples ( For sample mean estimator) 
yi.p <- (yi.m*xi.m)/mean(Xi) # --------------------------  ( For product estimator) 
yi.r <- (yi.m*mean(Xi))/xi.m # --------------------------  ( For ratio estimator) 
yi.e <- yi.m*exp((mean(Xi)-xi.m)/(mean(Xi)+xi.m)) # -----  ( For exponential estimator) 
yi.sq <- yi.m*(mean(Xi)/xi.m)^.5  # ---------------------  ( For squre-root estimator) 

# plotting those values
plot(xi.m,yi.m)
lines(xi.m,yi.p,col="blue")
points(xi.m,yi.r,col="forestgreen")
points(xi.m,yi.e,col="red")
lines(xi.m,yi.sq,col="green")

#____________________________________________________________________________ 
# Estimator plot for Yi = sqrt(Xi) 
#____________________________________________________________________________
Xi <- 1:10
Yi <- sqrt(Xi)

xi_s <- t(combn(Xi,5)) # Samples from Xi Population values  Auxiliary information
yi_s <- t(combn(Yi,5)) # Samples from Yi Population values 

xi.m <- rowMeans(xi_s) # mean of all xi_s samples  Auxiliary

yi.m <- rowMeans(yi_s) # ----------------------------------mean of all yi_s samples ( For sample mean estimator) 
yi.p <- (yi.m*xi.m)/mean(Xi) # --------------------------  ( For product estimator) 
yi.r <- (yi.m*mean(Xi))/xi.m # --------------------------  ( For ratio estimator) 
yi.e <- yi.m*exp((mean(Xi)-xi.m)/(mean(Xi)+xi.m)) # -----  ( For exponential estimator) 
yi.sq <- yi.m*(mean(Xi)/xi.m)^.5  # ---------------------  ( For squre-root estimator) 

# plotting those values
plot(xi.m,yi.m)
lines(xi.m,yi.p,col="blue")
points(xi.m,yi.r,col="forestgreen")
points(xi.m,yi.e,col="red")
lines(xi.m,yi.sq,col="green")

#____________________________________________________________________________ 
# Estimator plot for Yi = exp(Xi) 
#____________________________________________________________________________
Xi <- 1:10
Yi <- exp(Xi)

xi_s <- t(combn(Xi,5)) # Samples from Xi Population values  Auxiliary information
yi_s <- t(combn(Yi,5)) # Samples from Yi Population values 

xi.m <- rowMeans(xi_s) # mean of all xi_s samples  Auxiliary

yi.m <- rowMeans(yi_s) # ----------------------------------mean of all yi_s samples ( For sample mean estimator) 
yi.p <- (yi.m*xi.m)/mean(Xi) # --------------------------  ( For product estimator) 
yi.r <- (yi.m*mean(Xi))/xi.m # --------------------------  ( For ratio estimator) 
yi.e <- yi.m*exp((mean(Xi)-xi.m)/(mean(Xi)+xi.m)) # -----  ( For exponential estimator) 
yi.sq <- yi.m*(mean(Xi)/xi.m)^.5  # ---------------------  ( For squre-root estimator) 

# plotting those values
par(mfrow=c(2,2))
plot(xi.m,yi.m,main = "product estimator")
points(xi.m,yi.p,col="blue")

plot(xi.m,yi.m,main = "ratio estimator")
points(xi.m,yi.r,col="pink")

plot(xi.m,yi.m,main = "exponential estimator")
points(xi.m,yi.e,col="red")

plot(xi.m,yi.m,main = "square-root estimator")
points(xi.m,yi.sq,col="green")

par(mfrow=c(1,1))
