# Generated 5 set of Biveriate normal populations with population size 40 , 50, 60, 75 and 100  
# Here the X is the Auxiliary Information

set.seed(1);P1_X <- rnorm(n = 40,mean = 15,sd = 3) # X variable of all the population having mean 15 and variance 9
set.seed(1);P1_Y <- rnorm(n = 40,mean = 30,sd = 5) # Y variable of all the population having mean 40 and variance 25
set.seed(1);P2_X <- rnorm(n = 50,mean = 15,sd = 3)
set.seed(1);P2_Y <- rnorm(n = 50,mean = 30,sd = 5)
set.seed(1);P3_X <- rnorm(n = 60,mean = 15,sd = 3)
set.seed(1);P3_Y <- rnorm(n = 60,mean = 30,sd = 5)
set.seed(1);P4_X <- rnorm(n = 75,mean = 15,sd = 3)
set.seed(1);P4_Y <- rnorm(n = 75,mean = 30,sd = 5)
set.seed(1);P5_X <- rnorm(n = 100,mean = 15,sd = 3)
set.seed(1);P5_Y <- rnorm(n = 100,mean = 30,sd = 5)

#Created 5 population sets , using the data frame

P1 <- data.frame(P1_X,P1_Y);P1
P2 <- data.frame(P2_X,P2_Y);P2
P3 <- data.frame(P3_X,P3_Y);P3
P4 <- data.frame(P4_X,P4_Y);P4
P5 <- data.frame(P5_X,P5_Y);P5


# For Each Populations draw 3 samples ____________________________________

Sample <- function(p,n){
  set.seed(1)
  r <- sample(x = 1:nrow(p),size = n)
  s <- p[c(r),]
  return(s)
}
# For Population 1 
s1_1 <- Sample(P1,5);s1_1
s1_2 <- Sample(P1,10);s1_2
s1_3 <- Sample(P1,15);s1_3
# For Population 2
s2_1 <- Sample(P2,5);s2_1
s2_2 <- Sample(P2,10);s2_2
s2_3 <- Sample(P2,15);s2_3
# For Population 3 
s3_1 <- Sample(P3,5);s3_1
s3_2 <- Sample(P3,10);s3_2
s3_3 <- Sample(P3,15);s2_3
# For Population 4 
s4_1 <- Sample(P4,5);s4_1
s4_2 <- Sample(P4,10);s4_2
s4_3 <- Sample(P4,15);s4_3
# For Population 5 
s5_1 <- Sample(P5,5);s5_1
s5_2 <- Sample(P5,10);s5_2
s5_3 <- Sample(P5,15);s5_3

list <- list(s1_1,s1_2,s1_3,s2_1,s2_2,s2_3,s3_1,s3_2,s3_3,s4_1,s4_2,s4_3,s5_1,s5_2,s5_3)
sample_list <- list("s1_1"=s1_1,"s1_2"=s1_2,"s1_3"=s1_3,"s2_1"=s2_1,"s2_2"=s2_2,"s2_3"=s2_3,"s3_1"=s3_1,"s3_2"=s3_2,"s3_3"=s3_3,"s4_1"=s4_1,"s4_2"=s4_2,"s4_3"=s4_3,"s5_1"=s5_1,"s5_2"=s5_2,"s5_3"=s5_3)
sample_list[[1]][2]

#_________________________________________________________________________________________________________
#   | STARTING EXPERIMENT USING THE GENERATED DATA |
#_________________________________________________________________________________________________________


# 
# simple mean estimator _____ ybar
# 


sample_mean_y <- c()

for (i in 1:15) {
  mean(sample_list[[i]][,2]) -> sample_mean_y[i]
}

sample_mean_y # get all the sample means which should be equal to 30 as per population concern

diff1 <- abs(30- sample_mean_y)
which.min(diff1)
sample_list [which.min(diff1)]

# Conclusion Incase of larger sample size i.e 100 with sample size 5 

# 
# ratio estimator_______________ ybar*(Xbar / xbar)
# 

sample_mean_x <- c()

for (i in 1:15) {
  mean(sample_list[[i]][,1]) -> sample_mean_x[i]
}
sample_mean_x # get all the sample means which should be equal to 15 as per population concern
xbar <- sample_mean_x; ybar <- sample_mean_y ; Xbar <- 15;

ratio_estimator <- ybar*(Xbar / xbar)

diff2 <- abs(30- ratio_estimator)
which.min(diff2)
sample_list [which.min(diff2)]

plot(diff1,type = "l")
lines(diff2,type = "l")

# Conclusion Incase of larger sample size i.e 100 with sample size 5

# 
# Hartley Ross (1954)
# 
r_n <- c() 

for (i in 1:15) {
  mean((sample_list[[i]][2]/sample_list[[i]][1])[,1]) -> r_n[i]
}

r_n # which is the vector containing the "r_n_bar" values of all 15 samples 

n <- rep(x = c(5,10,15),5);n
N <- rep(x =c(40,50,60,75,100),c(3,3,3,3,3) );N
Y_rh <- (r_n*Xbar) + (  ( (n*(N-1)) / (N*(n-1)) ) * (ybar - (r_n*xbar))   )

diff3 <- abs(30- Y_rh)
which.min(diff3)
sample_list [which.min(diff3)]

# Conclusion Incase of larger sample size i.e 100 with sample size 5

plot(diff1,type = "l")
lines(diff2,type = "l")
lines(diff3,type = "l")

# 
